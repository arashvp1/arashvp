# PvResan

سلام

این سورس توسط ادمین اوپن شده و کاملترین سورس موجوده

برای آموزش ران کردن به 
<a href="http://www.telegram.me/nawr_i_man_bot">ادمین</a>
پیام بدید

یه تشکر  ویژه از دوستای خوبم    </br>
<a href="http://www.telegram.me/awmir_ho3in">awmir_ho3in</a></br>
<a href="http://www.telegram.me/FasTReaCtoR">FasTReaCtoR</a>

